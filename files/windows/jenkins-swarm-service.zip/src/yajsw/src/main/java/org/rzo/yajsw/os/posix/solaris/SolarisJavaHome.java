package org.rzo.yajsw.os.posix.solaris;

import org.apache.commons.configuration.Configuration;
import org.rzo.yajsw.os.posix.PosixJavaHome;

public class SolarisJavaHome extends PosixJavaHome
{

	public SolarisJavaHome(Configuration config)
	{
		super(config);
	}

}
