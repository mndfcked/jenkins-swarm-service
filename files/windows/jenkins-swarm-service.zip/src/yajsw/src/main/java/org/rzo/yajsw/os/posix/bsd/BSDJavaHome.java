package org.rzo.yajsw.os.posix.bsd;

import org.apache.commons.configuration.Configuration;
import org.rzo.yajsw.os.posix.PosixJavaHome;

public class BSDJavaHome extends PosixJavaHome
{

	public BSDJavaHome(Configuration config)
	{
		super(config);
	}

}
