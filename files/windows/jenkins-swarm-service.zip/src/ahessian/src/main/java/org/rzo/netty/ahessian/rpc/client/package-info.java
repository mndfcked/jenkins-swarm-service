/**
 * Provides hessian rpc client side handling
 * <br>
 * {@link HessianProxyFactory}  is the netty handler which handles
 * client side hessian RPC proxy requests.
 */
package org.rzo.netty.ahessian.rpc.client;