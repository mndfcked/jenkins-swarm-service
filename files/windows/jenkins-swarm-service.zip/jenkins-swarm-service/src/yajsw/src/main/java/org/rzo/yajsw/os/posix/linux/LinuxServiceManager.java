package org.rzo.yajsw.os.posix.linux;

import org.rzo.yajsw.os.posix.PosixServiceManager;

public class LinuxServiceManager extends PosixServiceManager
{

}
