package org.rzo.yajsw.os.posix.solaris;

import org.rzo.yajsw.os.posix.PosixServiceManager;

public class SolarisServiceManager extends PosixServiceManager
{

	/*
	 * public Service createService() { return new SolarisService(); }
	 * 
	 * public Service getService(String name) { // TODO Auto-generated method
	 * stub return null; }
	 * 
	 * public List getServiceList() { // TODO Auto-generated method stub return
	 * null; }
	 */

}
