package org.rzo.yajsw.os.posix.bsd.macosx;

import org.apache.commons.configuration.Configuration;
import org.rzo.yajsw.os.posix.bsd.BSDJavaHome;

public class MacOsXJavaHome extends BSDJavaHome
{

	public MacOsXJavaHome(Configuration config)
	{
		super(config);
	}

}
