/**
 * Extends classes from the package com.caucho.hessian.io, so that
 * they can be used in a non-servlet context.
 */
package org.rzo.netty.ahessian.rpc.io;